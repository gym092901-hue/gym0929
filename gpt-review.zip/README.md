# 멍냥사주 GPT 점검 패키지

이 폴더는 GPT가 localhost에 직접 접속하지 못할 때 업로드해서 검토할 수 있는 최신 스냅샷입니다.

1. `GPT_REVIEW_PROMPT.md` 내용을 GPT에 붙여넣으세요.
2. 더 정확한 점검을 원하면 이 폴더의 `.txt`, `.html`, `summary.json` 파일을 함께 업로드하세요.
3. 외부 URL로 검토받으려면 Vercel 배포 후 `https://배포주소/input`을 공유하세요.
4. 정식 production에서는 프리미엄 직접 접근과 PDF 저장 요청이 결제 없이 열리면 안 됩니다.

생성 기준 URL: http://127.0.0.1:3000
생성 시각: 2026-05-21T07:07:50.711Z
